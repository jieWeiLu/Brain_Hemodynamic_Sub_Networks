function [Wcon,Hcon] = aggregated_network_decomposition(Mbn,Tp,Tm,K, id_peo)
% Aggregated Network Decomposition
%
%  [Wcon,Hcon] = aggregated_network_decomposition(Mbn,Tp,Tm,K, id_peo)
%
%  Decomposing the dynamic brain networks into sub-networks based on 
%  aggregated effectiveness optimization of sub-networks in spanning 
%  network topology and cross-validation network variations
%
%  Inputs:
%      Mbn: dynamic brain network matrix
%      Tp: aggregated parameter iteration
%      Tm: aggregated matrix iteration
%      K: cross-validation fold number
%      id_peo: the index of each matrix in Mbn for patient id
%
%  Outputs:
%      Wcon: sub-network matrix
%      Hcon: dynamic activation coefficient matrix

num_peo = 50;

% Aggregated parameter optimization
result_final = [];
for rr = 1:Tp
    disp(rr)
    % Initialize the parameters
    r = randi([2,15]);
    alpha = rand(1)*2;
    delta = rand(1);
    
    % K-fold cross validation
    indices = crossvalind('Kfold',num_peo,K);
    
    % Calculate errors
    error_all = [];
    S_sub_network = [];
    for j = 1:K
        % People index for training and testing
        train_id = find(indices~=j);
        test_id = find(indices==j);
        
        % Find the index 
        loc_train = [];
        loc_test = [];
        for d = 1:length(id_peo)
            if ismember(id_peo(d),train_id)
                loc_train = [loc_train d];
            else
                loc_test = [loc_test d];
            end
        end
        
        % Extract matrices
        matrix_train = Mbn(:,loc_train);
        matrix_test = Mbn(:,loc_test);
        
        % Decomposition
        [m,n] = size(matrix_train);
        U0 = rand(m,r); V0 = rand(r,n);
        maxiter = 1e6; timelimit = 5;
        [Utrain,~,~,~] = HALSacc(matrix_train,U0,V0,alpha,delta,maxiter,timelimit);
        
        [m,n] = size(matrix_test);
        V0 = rand(r,n);
        [~,Vtest,~,~] = HALSacc2(matrix_test,Utrain,V0,alpha,delta,maxiter,timelimit);
        
        S_sub_network = cat(3,S_sub_network,Utrain);
        
        % Error
        error = norm(matrix_test - Utrain*Vtest,'fro')/sqrt(m*n);
        error_all = [error_all;error];
    
    end
    % Calculate factor f
    error_kf = mean(error_all);
    density = get_density(S_sub_network,K);
    f = density - error_kf;

    result_final = [result_final;r alpha delta f];
end

% Determine the final parameters
xsort = sortrows(result_final,4);
xsort_cut = xsort((Tp*0.75+1):Tp,1:3);
sn = mean(xsort_cut);
rf = round(sn(1)); alphaf = sn(2); deltaf = sn(3);

% Aggregated matrix optimization
Map = [];
for i = 1:Tm
    [m,n] = size(Mbn);
    U0 = rand(m,rf); V0 = rand(rf,n);
    maxiter = 1e6; timelimit = 5;
    [U,V,~,~] = HALSacc(Mbn,U0,V0,alphaf,deltaf,maxiter,timelimit);
    Map = [Map  U];
end

% Obtain Wcon
[m,n] = size(Map);
U0 = rand(m,rf); V0 = rand(rf,n);
maxiter = 1e6; timelimit = 5;
[Wcon,~,~,~] = HALSacc(Map,U0,V0,alphaf,deltaf,maxiter,timelimit);

% Obtain Hcon
[m,n] = size(Mbn);
V0 = rand(rf,n);
[~,Hcon,~,~] = HALSacc2(Mbn,Wcon,V0,alphaf,deltaf,maxiter,timelimit);




