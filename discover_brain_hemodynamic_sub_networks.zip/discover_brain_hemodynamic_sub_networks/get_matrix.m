function fea_up = get_matrix(data_window)
% Get Matrix
%
%  fea_up = get_matrix(data_window)
%
%  Extraction of network elements for a segment
%
%  Inputs:
%      data_window: the channel signals during a segment 
%
%  Outputs:
%      fea_up: the upper triangular elements of a segment

% Constructing functional networks
n_samples = size(data_window,1);
[~,~,pli]=fastfc_ps(data_window,n_samples*.1,1);

% Extracting the upper triangular elements
fea_up = [];
num_channel = size(pli,1);
for iup1 = 1:(num_channel-1)
    fea_up = [fea_up pli(iup1,(iup1+1):end)];
end
fea_up = fea_up';