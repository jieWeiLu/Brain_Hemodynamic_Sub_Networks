function density = get_density(Wall,rnum)

Cw = zeros(rnum,rnum);
nr = size(Wall,2);
for i = 1:rnum
    for j = 1:rnum
        
        % two matrices
        Wi = Wall(:,:,i);
        Wj = Wall(:,:,j);
        
        Cz = zeros(nr,nr);
        for z1 = 1:nr
            for z2 = 1:nr
                Wz1 = Wi(:,z1);
                Wz2 = Wj(:,z2);
                sim = get_sim(Wz1,Wz2);
                Cz(z1,z2) = sim;
            end
        end
        
        % similarity
        maxCz = max(Cz,[],2);
        pw = mean(maxCz);
        Cw(i,j) = pw;
        
    end
end

% calculate density
density = mean(clustering_coef_wu(Cw));