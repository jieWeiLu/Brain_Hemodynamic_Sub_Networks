function sim = get_sim(a,b)
sim = dot(a,b)/(norm(a)*norm(b));