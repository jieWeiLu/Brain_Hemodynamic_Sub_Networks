System requirements:
MATLAB R2021a

Main Function:
aggregated_network_decomposition.m -- the process to discover brain hemodynamic sub-networks
get_matrix.m -- construction of network elements during a segement

Other Function:
clustering_coef_wu.m: calculation of clustering coefficient
get_density.m: calculation of density
get_sim.m: calculation of similarity 
HALSacc.m: Nonnegative matrix factorization
HALSacc2.m: Nonnegative matrix factorization 2
fastfc_ps.mexw64 and libfftw3f-3.dll: calculating phase lag index
